export interface VoiceConfig {backendUrl:string;accountId:string;appId:string;supportName?:string;pushEnvironment?:'production'|'sandbox'}
export interface LoginPreparation {
  attemptId:string;
  installationId:string;
  platform:'android'|'ios';
  applicationId:string;
  pushEnvironment:'default'|'production'|'sandbox';
  codeChallenge:string;
  codeChallengeMethod:'S256';
}
export interface SessionInfo {userId:string;sessionId:string;expiresAt:string;sessionExpiresAt:string;authProtocol:2}
export type SessionState={status:'loggedOut'}|{status:'authenticated';session:SessionInfo}|{status:'loginRequired';reason:string};
export interface VoiceReadiness {sessionStatus:'LOGGED_OUT'|'VALID'|'UNKNOWN'|'EXPIRED';isLoggedIn:boolean;canCall:boolean;canReceive:boolean;userId:string|null;reasons:string[];checkedAt:string|null;controlConnected:boolean}
export interface CallSnapshot {callId:string;direction:'INBOUND'|'OUTBOUND';state:string;version:string;businessNumber:string|null;ringingExpiresAt:string|null;mediaExpiresAt:string|null;endedAt:string|null;endReason:string|null;deviceStatus:string|null;isOwner:boolean;presentable:boolean}
export interface AudioRoute {id:string;name:string;selected:boolean}
export type CallConnectionState='CONNECTING'|'CONNECTED'|'RECONNECTING';
export interface VoiceState {revision:number;sessionState:SessionState;readiness:VoiceReadiness;calls:CallSnapshot[];audioStates:Record<string,{muted:boolean;routes:AudioRoute[]}>;connectionStates:Record<string,CallConnectionState>}
export interface VoiceEvent {type:string;callId:string|null;code:string|null}
export interface NativeBridge {execute(method:string,args:Record<string,unknown>):Promise<unknown>;subscribe(name:'customerVoiceState'|'customerVoiceEvent',listener:(value:any)=>void):()=>void}
