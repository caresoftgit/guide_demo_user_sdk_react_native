import {createCustomerVoice,CustomerVoiceError} from './client';
import type {NativeBridge} from './types';
declare const require:(name:string)=>any;
let emitter:any;
function native(){
  const rn=require('react-native');
  const module=rn.NativeModules.CustomerVoiceReactNative;
  if(!module)throw new CustomerVoiceError('NATIVE_MODULE_NOT_LINKED');
  return {rn,module};
}
const bridge:NativeBridge={
  execute(method,args){try{return native().module.execute(method,args)}catch(e){return Promise.reject(e)}},
  subscribe(name,listener){const {rn,module}=native();emitter??=new rn.NativeEventEmitter(module);const subscription=emitter.addListener(name,listener);return()=>subscription.remove()},
};
export const CustomerVoice=createCustomerVoice(bridge);
export {CustomerVoiceError};
export type * from './types';
export type {CustomerVoiceClient} from './client';
