require 'json'
package = JSON.parse(File.read(File.join(__dir__, 'package.json')))
Pod::Spec.new do |s|
  s.name = 'CustomerVoiceReactNative'
  s.version = package['version']
  s.summary = package['description']
  s.homepage = 'https://caresoft.vn'
  s.license = { :type => 'Proprietary' }
  s.author = { 'Caresoft' => 'https://caresoft.vn' }
  s.source = { :git => 'https://github.com/caresoftgit/user_voice_sdk_react_native.git', :tag => 'v' + s.version.to_s }
  s.platform = :ios, '15.1'
  s.swift_version = '5.0'
  s.source_files = 'ios/*.{h,m,mm,swift}'
  s.vendored_frameworks = 'ios/Vendor/*.xcframework'
  s.resources = 'ios/Vendor/Resources/*.bundle'
  s.preserve_paths = 'ios/Vendor/Licenses/**/*'
  s.frameworks = 'CallKit', 'PushKit', 'AVFoundation', 'UserNotifications', 'SwiftUI'
  s.dependency 'React-Core'
end
