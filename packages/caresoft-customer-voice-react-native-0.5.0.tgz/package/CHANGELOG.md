# 0.5.0

- Added prepareLogin and loginWithTicket with native PKCE ownership.
- Exposed absolute session expiry and protocol metadata through session state.
- Updated native core/UI distributions to 0.5.0.
- Demo uses an application-owned authenticated ticket callback; no enterprise login backend or credential form is shipped.
- Added the host-session integration contract and logout/revocation guidance.
- Refreshed portable iOS artifacts and reject case-insensitive raw, mapped or JSON-escaped developer paths during packaging; omit development ABI/source-location metadata.

# Changelog

## 0.1.3

- Bộ phân phối dùng native Android core/UI 0.4.2, iOS 0.1.2; API và luồng cuộc gọi giữ nguyên.
- Build lại framework iOS với source prefix maps, loại debug/source-location metadata khỏi gói public. Verifier kiểm tra cả đường dẫn máy build, private key và nội dung AAR/JAR lồng nhau.
- Bổ sung liên kết source/demo, hướng dẫn đóng gói và kiểm chứng package.

## 0.1.2

- Bổ sung version/build trong Info.plist của framework iOS cho App Store Connect.

## 0.1.1

- Android core/UI 0.4.2 sửa vòng đời foreground service.
- `showCall(callId)` cho phép mở lại cuộc gọi còn presentable.

## 0.1.0

- API React Native dùng chung core/UI native Android và iOS: phiên, readiness, gọi/nhận, push, audio và phục hồi kết nối.
