# Third-party notices

Native distributions include LiveKit, WebRTC, SwiftProtobuf, Swift Collections, JWTKit and dependencies under their upstream licenses. Full notices are kept in `ios/Vendor/Licenses/`. Android dependencies resolve through pinned Maven metadata and retain upstream licenses. React Native and React are provided by the host under their upstream licenses. Do not remove the native resource/privacy bundles or license files from a distribution.
