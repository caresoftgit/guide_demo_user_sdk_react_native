#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>
@interface RCT_EXTERN_MODULE(CustomerVoiceReactNative, RCTEventEmitter)
RCT_EXTERN_METHOD(execute:(NSString *)method arguments:(NSDictionary *)arguments resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject)
@end
