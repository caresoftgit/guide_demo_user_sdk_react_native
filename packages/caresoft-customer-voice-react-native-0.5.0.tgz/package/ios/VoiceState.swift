import Foundation
import CustomerVoice

@MainActor enum VoiceState {
 static var revision=0
 static func date(_ value: Date?) -> Any {value.map {ISO8601DateFormatter().string(from:$0)} ?? NSNull() as Any}
 static func preparation(_ p: LoginPreparation)->[String:Any] {["attemptId":p.attemptID,"installationId":p.installationID,"platform":p.platform,"applicationId":p.applicationID,"pushEnvironment":p.pushEnvironment,"codeChallenge":p.codeChallenge,"codeChallengeMethod":p.codeChallengeMethod]}
 static func session(_ s: SessionInfo)->[String:Any] {["userId":s.userID,"sessionId":s.sessionID,"expiresAt":date(s.expiresAt),"sessionExpiresAt":date(s.sessionExpiresAt),"authProtocol":s.authProtocol]}
 static func readiness(_ r: VoiceReadiness)->[String:Any] {["sessionStatus":r.sessionStatus.rawValue,"isLoggedIn":r.isLoggedIn,"canCall":r.canCall,"canReceive":r.canReceive,"userId":r.userID ?? NSNull() as Any,"reasons":r.reasons,"checkedAt":date(r.checkedAt),"controlConnected":r.controlConnected]}
 static func route(_ r: AudioRoute)->[String:Any] {["id":r.id,"name":r.name,"selected":r.selected]}
 static func call(_ c: CallSnapshot)->[String:Any] {["callId":c.callID,"direction":c.direction.rawValue,"state":c.state,"version":String(c.version),"businessNumber":c.businessNumber ?? NSNull() as Any,"ringingExpiresAt":date(c.ringingExpiresAt),"mediaExpiresAt":date(c.mediaExpiresAt),"endedAt":date(c.endedAt),"endReason":c.endReason ?? NSNull() as Any,"deviceStatus":c.deviceStatus ?? NSNull() as Any,"isOwner":c.isOwner,"presentable":CustomerVoice.shared.isCallPresentable(c.callID)]}
 static func snapshot()->[String:Any] {
  let v=CustomerVoice.shared;var s:[String:Any]
  switch v.sessionState {case .loggedOut:s=["status":"loggedOut"];case .authenticated(let session):s=["status":"authenticated","session":Self.session(session)];case .loginRequired(let reason):s=["status":"loginRequired","reason":reason]}
  revision+=1
  return ["revision":revision,"sessionState":s,"readiness":readiness(v.readiness),"calls":v.calls.map(call),"audioStates":v.audioStates.mapValues {["muted":$0.muted,"routes":$0.routes.map(route)] as [String:Any]},"connectionStates":v.connectionStates.mapValues {$0.rawValue.uppercased()}]
 }
}
