import Foundation
import Combine
import React
import AVFoundation
import CustomerVoice

@objc(CustomerVoiceReactNative) final class CustomerVoiceModule: RCTEventEmitter {
 private var observations=Set<AnyCancellable>()
 private var listening=false
 override static func requiresMainQueueSetup()->Bool {true}
 override func supportedEvents()->[String]! {["customerVoiceState","customerVoiceEvent"]}
 override func startObserving() {Task {@MainActor in
  self.listening=true;let v=CustomerVoice.shared
  Publishers.MergeMany(v.$sessionState.map{_ in ()}.eraseToAnyPublisher(),v.$readiness.map{_ in ()}.eraseToAnyPublisher(),v.$calls.map{_ in ()}.eraseToAnyPublisher(),v.$audioStates.map{_ in ()}.eraseToAnyPublisher(),v.$connectionStates.map{_ in ()}.eraseToAnyPublisher()).receive(on:DispatchQueue.main).sink {[weak self] _ in guard let self,self.listening else{return};self.sendEvent(withName:"customerVoiceState",body:VoiceState.snapshot())}.store(in:&self.observations)
  v.events.receive(on:DispatchQueue.main).sink {[weak self] e in guard let self,self.listening else{return};self.sendEvent(withName:"customerVoiceEvent",body:["type":e.type,"callId":e.callID ?? NSNull() as Any,"code":e.code ?? NSNull() as Any])}.store(in:&self.observations)
 }}
 override func stopObserving() {Task {@MainActor in self.listening=false;self.observations.removeAll()}}
 @objc(execute:arguments:resolve:reject:) func execute(_ method: String,arguments args: [String:Any],resolve: @escaping RCTPromiseResolveBlock,reject: @escaping RCTPromiseRejectBlock) {
  Task {@MainActor in
   do {
    let v=CustomerVoice.shared
    func string(_ key: String)throws->String {guard let value=args[key] as? String else {throw VoiceError("INVALID_ARGUMENT")};return value}
    if !["getState","initialize","canShowIncomingScreen"].contains(method),v.configuration==nil {throw VoiceError("NATIVE_BOOTSTRAP_REQUIRED")}
    var result:Any?=nil
    switch method {
    case "initialize":
     guard let c=v.configuration else {throw VoiceError("NATIVE_BOOTSTRAP_REQUIRED")}
     guard c.backendURL.absoluteString==((try string("backendUrl"))),c.accountID==((try string("accountId"))),c.appID==((try string("appId"))),c.pushEnvironment.rawValue==(args["pushEnvironment"] as? String ?? "production") else {throw VoiceError("CONFIGURATION_MISMATCH")}
    case "getState": result=VoiceState.snapshot()
    case "prepareLogin": result=VoiceState.preparation(try v.prepareLogin())
    case "loginWithTicket": result=VoiceState.session(try await v.loginWithTicket(attemptID:string("attemptId"),ticket:string("ticket")))
    case "logout":try await v.logout()
    case "checkReadiness":result=VoiceState.readiness(try await v.checkReadiness())
    case "call":result=VoiceState.call(try await v.call(businessNumber:string("businessNumber")))
    case "answer":try await v.answer(callID:string("callId"))
    case "reject":try await v.reject(callID:string("callId"))
    case "hangup":try await v.hangup(callID:string("callId"))
    case "setMuted":guard let muted=args["muted"] as? Bool else {throw VoiceError("INVALID_ARGUMENT")};try await v.setMuted(callID:string("callId"),muted:muted)
    case "getAvailableAudioRoutes":result=v.getAvailableAudioRoutes(callID:try string("callId")).map(VoiceState.route)
    case "selectAudioRoute":let id=try string("callId");let routeID=try string("routeId");guard let route=v.getAvailableAudioRoutes(callID:id).first(where:{$0.id==routeID}) else {throw VoiceError("ROUTE_UNAVAILABLE")};try await v.selectAudioRoute(callID:id,route:route)
    case "sendDtmf":let digit=try string("digit");guard digit.count==1,let value=digit.first else {throw VoiceError("INVALID_DTMF")};try await v.sendDtmf(callID:string("callId"),digit:value)
    case "updatePushToken":try await v.updatePushToken(string("token"))
    case "unregisterPushToken":try await v.unregisterPushToken()
    case "synchronize":try await v.synchronize();result=VoiceState.snapshot()
    case "resume":VoiceBootstrap.resume()
    case "showCall":try VoiceBootstrap.showCall(string("callId"))
    case "canShowIncomingScreen":result=true
    case "requestIncomingScreenPermission":break // iOS CallKit has no Android full-screen special access.
    case "requestMicrophonePermission":result=await withCheckedContinuation {c in AVAudioSession.sharedInstance().requestRecordPermission {c.resume(returning:$0)}};v.resume()
    default:throw VoiceError("UNSUPPORTED_OPERATION")
    }
    resolve(result)
   } catch {
    let error=error as? VoiceError ?? VoiceError("VOICE_OPERATION_FAILED")
    reject(error.code,error.code,NSError(domain:"CustomerVoice",code:error.status,userInfo:["code":error.code,"status":error.status]))
   }
  }
 }
}
