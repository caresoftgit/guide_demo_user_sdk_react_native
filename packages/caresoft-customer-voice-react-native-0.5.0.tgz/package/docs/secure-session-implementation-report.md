# Secure session React Native implementation report

## Delivered sources

- `.worktrees/user_voice_sdk_react_native` contains the 0.5.0 TypeScript facade, Kotlin/Swift bridge maps and native packaging scripts.
- `.worktrees/guide_demo_user_sdk_react_native` contains the enterprise-login demo, server-side host simulator and Android/iOS setup and acceptance guides.

`prepareLogin()` exposes only attempt/installation/platform/application/push metadata and a public S256 challenge. `loginWithTicket(attemptId, ticket)` delegates exchange to native and exposes only userId, sessionId, expiresAt, sessionExpiresAt and authProtocol. Native owns verifier, access/refresh credentials, refresh single-flight, secure storage and call capability. Native event/state maps enumerate public fields explicitly.

The demo authenticates an explicitly enabled development fixture on the enterprise host. Host identity comes from its server-side principal mapping to a preconfigured customer ID. The bootstrap schema rejects unknown fields and client identity/verifier overrides. Integration credentials remain in server environment configuration. The application configuration generator accepts public application fields and rejects secret/identity injection before writing bundles.

Host logout persists an inactive enterprise session and a scope-bound revoke outbox before returning HTTP 202. It atomically replaces a mode-0600 state file with file and directory fsync, enforces a single writer, retries the same revoke request UUID after response loss/restart, and polls the gateway's cleanup_status pending/done field. Its authenticated status route exposes host active/pending/completed metadata. A directory-sync failure after replacement keeps the process's inactive session consistent with the state already written.

## Verified checks

- SDK `npm test` passed 8 tests and compiled declarations.
- SDK `npm run typecheck` passed.
- Demo `npm test -- --watch=false` passed 13 tests across four suites, including enterprise bootstrap and host logout after a native revoke error.
- Demo `npm run typecheck` passed.
- Host `node --test host/test/*.test.cjs` on Node 24 passed seven tests using real loopback fixture servers and temporary disk state. Tests cover explicit fixture enablement, wrong-password rejection, authenticated bootstrap, identity/verifier override rejection, server principal mapping, safe response projection, durable logout retry across restart, stable request UUIDs, fresh host session UUIDs, pending/done status, configuration secret rejection, persisted scope mismatch and post-rename fsync failure consistency.
- Android bridge `testDebugUnitTest` and demo `:app:lint` passed with 127 Gradle tasks.
- Android demo debug and release consumer builds passed against native 0.5.0, with 234 Gradle tasks. Log is `/private/tmp/rn-secure-android-build.log`.
- Android core/UI 0.5.0 local Maven publication passed. The upstream native core owner reported 114 unit executions, 26 emulator tests, lint and release builds.
- `git diff --check` passed for both owned repositories.

## Final package and native consumer verification

Final inputs were Android core/UI 0.5.0 local Maven artifacts from native commit `59cabbe` and the iOS `deliverables/0.5.0` distribution rebuilt with the expiry fixes. The native owners reported 114 Android unit executions, 26 emulator tests, lint/release checks and 64 Swift tests.

- `python3 scripts/prepare-native.py --ios ../user_voice_sdk_ios/deliverables/0.5.0 --android ../user_voice_sdk_android/deliverables/maven` completed and produced 330 native SHA-256 entries.
- `npm pack --ignore-scripts` produced `caresoft-customer-voice-react-native-0.5.0.tgz`.
- `python3 scripts/verify-package.py caresoft-customer-voice-react-native-0.5.0.tgz` passed native checksum, resource/license/privacy, platform-slice, developer-path and excluded-file checks.
- The demo installed that local package, updated its dependency/lockfile to 0.5.0 and removed the old 0.1.3 tarball. `packages/SHA256SUMS` verifies the delivered archive.
- Final-package demo Jest passed 13 tests, TypeScript passed and host tests passed seven tests against the canonical revoke body and `cleanup_status` response.
- Android `:app:assembleDebug :app:assembleRelease :caresoft_customer-voice-react-native:testDebugUnitTest :app:lint --offline --no-daemon` passed with 285 tasks. The bridge's six native tests had zero failures/errors. Log is `/private/tmp/rn-final-android-consumer.log`.
- iOS `pod install --no-repo-update` completed with 88 installed pods. `xcodebuild` for the CustomerVoiceDemo workspace/scheme in Release, iOS Simulator arm64 and `CODE_SIGNING_ALLOWED=NO` succeeded. Log is `/private/tmp/rn-final-ios-consumer.log`.
- Native Android and iOS now reject persisted protocol-1 credentials in their default secure configurations. New RN login dispatchers expose prepareLogin/loginWithTicket.

Artifacts are available under the demo worktree at `packages/caresoft-customer-voice-react-native-0.5.0.tgz`, `android/app/build/outputs/apk/debug/app-debug.apk`, `android/app/build/outputs/apk/release/app-release.apk` and `ios/build/consumer/Build/Products/Release-iphonesimulator/CustomerVoiceDemo.app`. APK release signing uses the demo debug key. The iOS build is an unsigned simulator artifact.

The simulator uses the canonical HOST revoke body with `scope` and `host_session_ref`. Credential scope supplies the account/app namespace. Gateway authority is committed before asynchronous cleanup, and polling observes `cleanup_status`. Host status maps completed cleanup to `completed`.

The offline install initially lacked npm peer metadata. Reinstalling the local tarball with `--legacy-peer-deps` succeeded against the demo's pinned React 19.3/React Native 0.88.1 dependencies. Initial Android verification used the system SDK path lacking platform 37. The consumer build passed with the project's already-provisioned SDK 37 toolchain.

## Runtime acceptance conditions

End-to-end acceptance requires an enabled protocol-2 gateway, scoped integration credential, configured tenant/app/platform and customer ownership, durable gateway dependencies/replay key, trusted HTTPS enterprise host, destination routing, push provisioning and signed Android/iPhone applications. Real device checks remain necessary for background/cold-start/locked handling, APNs/FCM, CallKit/Telecom, two-way audio, Wi-Fi/mobile transitions, natural session expiry and explicit revoke/media cleanup.

The demo keeps its enterprise bearer in JavaScript memory. A pending host logout delivery can be retried while that JS process remains alive. Closing it before the host receives the request loses that pending delivery. After host receipt, the durable server outbox continues after restart. Existing native Voice credentials can restore independently of fixture enterprise login. Production integrations supply their enterprise session storage and durable logout delivery at this boundary.

The fixture's host-session lifetime is one day. It uses a single preconfigured user mapping, bearer authorization and a loopback listener behind a trusted development HTTPS reverse proxy. These are implementation choices for the simulator. Its configuration and state are private server inputs.

Jest emits the existing SafeAreaView deprecation warning. iOS emits upstream React umbrella-header warnings and an existing empty location-purpose-string warning. Gradle emits deprecation and upstream lint-registry warnings. These builds passed. Device and production gateway acceptance remains subject to the runtime conditions above.
