# Phiên Voice protocol 2 trên React Native

Ứng dụng giữ cơ chế đăng nhập/SSO hiện có. Backend xác thực phiên doanh nghiệp, ánh xạ principal sang `user_id` Caresoft, rồi cấp ticket một lần bằng credential tích hợp chỉ lưu ở server. App không cho người dùng nhập `user_id` hoặc API token Caresoft.

1. Native bootstrap từ Application/AppDelegate trước JavaScript, kể cả cold start do push.
2. `prepareLogin()` tạo verifier trong memory native và trả bảy trường preparation công khai.
3. HTTP client đã xác thực của ứng dụng gửi preparation tới backend doanh nghiệp; server thêm định danh khách hàng, Account/App và phiên host từ dữ liệu đáng tin cậy.
4. Backend trả `{attempt_id, login_ticket, expires_at}`; app kiểm tra response rồi gọi `loginWithTicket(attemptId, ticket)`.
5. Native exchange PKCE, giữ access/refresh và tự quản lý rotation, push, readiness, cuộc gọi và UI native. JS chỉ nhận metadata phiên/state.

Preparation sống tối đa 120 giây; ticket một lần mặc định 60 giây; access thường 15 phút. Hạn tuyệt đối do chính sách server và phiên host quyết định, refresh không kéo dài hạn đó. Refresh single-flight lưu UUID trước HTTP và retry cùng payload/UUID trong cửa sổ 30 giây. Exchange mất response cần preparation/ticket mới.

Native dùng Keychain trên iOS và storage được bảo vệ bằng Android Keystore. Không lưu token vào AsyncStorage, config hoặc JS persistence. Verifier/ticket không persist. Protocol 1 không dùng cho tích hợp mới. Không đưa credentials, push payload hay ticket vào log/analytics/crash report.

`logout()` dọn local trước và cố thu hồi phiên Voice; lỗi revoke không khôi phục token đã xóa. Nút Ngắt Voice không đăng xuất tài khoản doanh nghiệp. Đăng xuất ứng dụng phải gọi cả SDK logout và logout backend, kể cả một bên lỗi; tuần tự hóa với kết nối/chuyển tài khoản. Backend vô hiệu hóa phiên và ghi durable HOST-revoke outbox cùng transaction; worker retry/poll đến khi cleanup hoàn tất. Logout offline chưa bảo đảm thu hồi server ngay.

Hết hạn tự nhiên chặn cuộc gọi mới; cuộc gọi ACTIVE có thể tiếp tục bằng capability giới hạn tới deadline server. Explicit revoke/logout dừng quyền phiên/media. Lỗi mạng có thể cho readiness UNKNOWN; không tự bootstrap lặp khi offline. `canReceive` không thay kiểm thử push thực tế.

HTTPS/TLS bảo vệ API, WSS và WebRTC DTLS-SRTP bảo vệ giao tiếp/media. PKCE chứng minh sở hữu verifier; không thay xác thực doanh nghiệp hoặc chứng thực thiết bị.

Xem [API](api.md) và [hợp đồng bootstrap đầy đủ](https://github.com/caresoftgit/guide_demo_user_sdk_react_native/blob/main/docs/host-bootstrap.md), gồm payload, TTL, logout/outbox và wiring HTTP client.
