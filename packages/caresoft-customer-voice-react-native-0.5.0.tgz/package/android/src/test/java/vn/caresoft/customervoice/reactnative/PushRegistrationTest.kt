package vn.caresoft.customervoice.reactnative
import kotlinx.coroutines.*
import kotlinx.coroutines.test.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.junit.Test
import org.junit.Assert.*
@OptIn(ExperimentalCoroutinesApi::class)
class PushRegistrationTest {
 @Test fun rotationDuringRequestRegistersLatestWithoutResume()=runTest {
  val gate=CompletableDeferred<Unit>();val values=mutableListOf<String>();val push=PushRegistration(this,{"one"}) {values.add(it);if(it=="old")gate.await()}
  push.update("old");runCurrent();push.update("new");gate.complete(Unit);runCurrent();assertEquals(listOf("old","new"),values)
 }
 @Test fun optOutSurvivesResumeAndRotationButNewLoginRegistersAgain()=runTest {
  var session="one";val values=mutableListOf<String>();val push=PushRegistration(this,{session}){values.add(it)}
  push.update("token");runCurrent();push.suspendCurrentSession();push.reconcile();push.update("new");runCurrent();assertEquals(listOf("token"),values)
  session="two";push.reconcile();runCurrent();assertEquals(listOf("token","new"),values)
 }
 @Test fun registrationForOldSessionCannotReplayAfterReplacement()=runTest {
  var session="one";val gate=CompletableDeferred<Unit>();var requests=0;val push=PushRegistration(this,{session}) {requests++;gate.await()}
  push.update("token");runCurrent();session="two";push.reconcile();runCurrent();gate.complete(Unit);runCurrent();assertEquals(2,requests)
 }
 @Test fun explicitUpdateReenablesOptedOutSession()=runTest {
  val values=mutableListOf<String>();val push=PushRegistration(this,{"one"}){values.add(it)}
  push.update("old");runCurrent();push.suspendCurrentSession();push.updateExplicit("explicit");push.reconcile();runCurrent()
  assertEquals(listOf("old","explicit"),values)
 }
 @Test fun failureDoesNotSpinAndRetriesOnNextResume()=runTest {
  var requests=0;val push=PushRegistration(this,{"one"}){requests++;if(requests==1)error("offline")}
  push.update("token");runCurrent();assertEquals(1,requests);push.reconcile();runCurrent();assertEquals(2,requests)
 }
 @Test fun idleControlReconnectRetriesFailedRegistrationWithoutResume()=runTest {
  var requests=0;val connected=MutableStateFlow(false)
  val push=PushRegistration(backgroundScope,{"one"}){requests++;if(requests==1)error("offline")}
  push.observeControlConnection(connected);push.update("token");runCurrent();assertEquals(1,requests)
  connected.value=true;runCurrent();assertEquals(2,requests)
 }
}
