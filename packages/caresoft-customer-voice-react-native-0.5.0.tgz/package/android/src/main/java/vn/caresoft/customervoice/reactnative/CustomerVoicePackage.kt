package vn.caresoft.customervoice.reactnative
import com.facebook.react.ReactPackage
import com.facebook.react.bridge.*
import com.facebook.react.uimanager.ViewManager
class CustomerVoicePackage: ReactPackage {
 override fun createNativeModules(context: ReactApplicationContext): List<NativeModule> = listOf(CustomerVoiceModule(context))
 override fun createViewManagers(context: ReactApplicationContext): List<ViewManager<*,*>> = emptyList()
}
