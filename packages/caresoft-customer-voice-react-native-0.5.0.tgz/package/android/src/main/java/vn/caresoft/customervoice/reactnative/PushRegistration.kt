package vn.caresoft.customervoice.reactnative

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

/** Main-thread adapter for the host's latest FCM token. The native core owns the session. */
internal class PushRegistration(
 private val scope: CoroutineScope,
 private val session: () -> String?,
 private val register: suspend (String) -> Unit
) {
 private var token: String? = null
 private var disabledSession: String? = null
 private var registered: Pair<String,String>? = null
 private var runningSession: String? = null
 private var job: Deferred<Result<Unit>>? = null

 fun observeControlConnection(connected: Flow<Boolean>) {
  scope.launch {connected.distinctUntilChanged().collect {if(it) reconcile()}}
 }

 fun update(value: String) { token=value; reconcile() }

 fun suspendCurrentSession() {
  disabledSession=session()
  registered=null
  job?.cancel(); job=null
 }

 suspend fun updateExplicit(value: String) {
  disabledSession=null
  token=value
  reconcile()?.await()?.getOrThrow()
 }

 fun reconcile(): Deferred<Result<Unit>>? {
  val captured=session()
  if(captured==null || captured==disabledSession) {job?.cancel();job=null;return null}
  if(token==null) return null
  if(job?.isActive==true && runningSession==captured) return job
  job?.cancel();runningSession=captured
  job=scope.async {
   try {
    while(session()==captured && disabledSession!=captured) {
     val value=token ?: break
     if(registered==Pair(captured,value)) break
     register(value)
     // A response for the previous session must never mark the new one registered.
     if(session()!=captured || disabledSession==captured) break
     registered=Pair(captured,value)
    }
    Result.success(Unit)
   } catch(e: CancellationException) {throw e}
   catch(e: Exception) {Result.failure(e)} // Automatic retries occur on resume/reconnect only.
  }
  return job
 }
}
