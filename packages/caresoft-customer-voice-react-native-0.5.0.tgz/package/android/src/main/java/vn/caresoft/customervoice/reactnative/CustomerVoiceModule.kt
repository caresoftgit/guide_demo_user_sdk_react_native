package vn.caresoft.customervoice.reactnative

import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.facebook.react.modules.core.PermissionAwareActivity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import vn.caresoft.customervoice.*
import vn.caresoft.customervoice.ui.CustomerVoiceUi
import kotlin.coroutines.resume

class CustomerVoiceModule(private val react: ReactApplicationContext): ReactContextBaseJavaModule(react) {
 private val listeners=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
 override fun getName()="CustomerVoiceReactNative"
 override fun initialize() {
  super.initialize()
  listeners.launch {combine(CustomerVoice.sessionState,CustomerVoice.readiness,CustomerVoice.calls,CustomerVoice.audioStates,CustomerVoice.connectionStates){_,_,_,_,_->VoiceState.snapshot()}.collect {emit("customerVoiceState",it)}}
  listeners.launch {CustomerVoice.events.collect {emit("customerVoiceEvent",mapOf("type" to it.type,"callId" to it.callId,"code" to it.code))}}
 }
 private fun emit(name: String,value: Map<String,Any?>) {if(react.hasActiveReactInstance()) react.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java).emit(name,Arguments.makeNativeMap(value))}
 @ReactMethod fun addListener(name: String) {}
 @ReactMethod fun removeListeners(count: Double) {}
 override fun invalidate() {listeners.cancel();super.invalidate()}
 @ReactMethod fun execute(method: String,args: ReadableMap,promise: Promise) {
  // Operations outlive the JS observer. A reload must not cancel an in-flight native call.
  VoiceBootstrap.scope.launch {
   try {
    fun string(key: String)=args.getString(key) ?: throw VoiceException("INVALID_ARGUMENT")
    if(method!="getState" && method!="initialize" && method!="canShowIncomingScreen") VoiceBootstrap.requireInitialized()
    val result: Any?=when(method) {
     "initialize" -> {VoiceBootstrap.checkConfiguration(string("backendUrl"),string("accountId"),string("appId"));null}
     "getState" -> VoiceState.snapshot()
     "prepareLogin" -> VoiceState.preparation(CustomerVoice.prepareLogin())
     "loginWithTicket" -> VoiceState.session(CustomerVoice.loginWithTicket(string("attemptId"),string("ticket")))
     "logout" -> {CustomerVoice.logout();null}
     "checkReadiness" -> VoiceState.readiness(CustomerVoice.checkReadiness())
     "call" -> VoiceState.call(CustomerVoice.call(string("businessNumber")))
     "answer" -> {CustomerVoice.answer(string("callId"));null}
     "reject" -> {CustomerVoice.reject(string("callId"));null}
     "hangup" -> {CustomerVoice.hangup(string("callId"));null}
     "setMuted" -> {CustomerVoice.setMuted(string("callId"),args.getBoolean("muted"));null}
     "getAvailableAudioRoutes" -> CustomerVoice.getAvailableAudioRoutes(string("callId")).map(VoiceState::route)
     "selectAudioRoute" -> {val id=string("callId");val route=CustomerVoice.getAvailableAudioRoutes(id).firstOrNull {it.id==string("routeId")} ?: throw VoiceException("ROUTE_UNAVAILABLE");CustomerVoice.selectAudioRoute(id,route);null}
     "sendDtmf" -> {val d=string("digit");if(d.length!=1)throw VoiceException("INVALID_DTMF");CustomerVoice.sendDtmf(string("callId"),d[0]);null}
     "updatePushToken" -> {VoiceBootstrap.updatePushToken(string("token"));null}
     "unregisterPushToken" -> {VoiceBootstrap.unregisterPushToken();null}
     "synchronize" -> {CustomerVoice.synchronize();VoiceState.snapshot()}
     "resume" -> {VoiceBootstrap.resume();null}
     "showCall" -> {CustomerVoiceUi.showCall(react,string("callId"));null}
     "canShowIncomingScreen" -> CustomerVoiceUi.canShowIncomingScreen(react)
     "requestIncomingScreenPermission" -> {val activity=react.currentActivity ?: throw VoiceException("ACTIVITY_REQUIRED");CustomerVoiceUi.requestIncomingScreenPermission(activity);null}
     "requestMicrophonePermission" -> microphonePermission()
     else -> throw VoiceException("UNSUPPORTED_OPERATION")
    }
    if(react.hasActiveReactInstance()) promise.resolve(when(result){is Map<*,*> -> Arguments.makeNativeMap(result as Map<String,Any?>);is List<*> -> Arguments.makeNativeArray(result);else -> result})
   } catch(e: Exception) {
    val code=when(e){is VoiceException->e.code;is IllegalArgumentException->"INVALID_ARGUMENT";else->"VOICE_OPERATION_FAILED"}
    if(react.hasActiveReactInstance())promise.reject(code,code,Arguments.createMap().apply {putString("code",code);putInt("status",(e as? VoiceException)?.status ?: 0)})
   }
  }
 }
 private suspend fun microphonePermission(): Boolean {
  if(ContextCompat.checkSelfPermission(react,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)return true
  val activity=react.currentActivity as? PermissionAwareActivity ?: throw VoiceException("ACTIVITY_REQUIRED")
  return suspendCancellableCoroutine {c->activity.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),7631){_,_,grants->if(c.isActive)c.resume(grants.firstOrNull()==PackageManager.PERMISSION_GRANTED);true}}
 }
}
