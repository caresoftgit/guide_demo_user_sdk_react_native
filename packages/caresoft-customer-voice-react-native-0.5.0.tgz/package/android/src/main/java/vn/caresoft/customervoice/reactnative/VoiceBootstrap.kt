package vn.caresoft.customervoice.reactnative

import android.app.Application
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.map
import vn.caresoft.customervoice.*
import vn.caresoft.customervoice.ui.CustomerVoiceUi

/** Application lifetime; React Native reload must not end a native call. No Firebase dependency. */
object VoiceBootstrap {
 val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
 private var configuration: VoiceConfig?=null
 private val push=PushRegistration(scope,{
  (CustomerVoice.sessionState.value as? SessionState.Authenticated)?.session?.sessionId
 }) {CustomerVoice.updatePushToken(it)}
 fun initialize(app: Application,backendUrl: String,accountId: String,appId: String,supportName: String="Chăm sóc khách hàng") {
  val config=VoiceConfig(backendUrl,accountId,appId,supportName,CustomerVoiceUi.incomingIntent(app))
  CustomerVoice.initialize(app,config)
  if(configuration==null) {
   CustomerVoiceUi.install(app,supportName)
   scope.launch {CustomerVoice.sessionState.collect {reconcilePush()}}
   push.observeControlConnection(CustomerVoice.readiness.map {it.controlConnected})
  }
  configuration=config
 }
 fun checkConfiguration(backendUrl: String,accountId: String,appId: String) {
  val c=configuration ?: throw VoiceException("NATIVE_BOOTSTRAP_REQUIRED")
  if(c.backendUrl!=backendUrl || c.accountId!=accountId || c.appId!=appId) throw VoiceException("CONFIGURATION_MISMATCH")
 }
 fun requireInitialized() { if(configuration==null) throw VoiceException("NATIVE_BOOTSTRAP_REQUIRED") }
 fun handleRemoteMessage(data: Map<String,String>): Boolean = CustomerVoice.handleRemoteMessage(data)
 fun onNewPushToken(value: String) {scope.launch {push.update(value)}}
 suspend fun updatePushToken(value: String) {push.updateExplicit(value)}
 suspend fun unregisterPushToken() {push.suspendCurrentSession();CustomerVoice.unregisterPushToken()}
 fun resume() {requireInitialized();CustomerVoice.resume();reconcilePush()}
 private fun reconcilePush() {push.reconcile()}
}
