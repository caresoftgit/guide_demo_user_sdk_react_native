import type {NativeBridge,VoiceState,VoiceEvent,VoiceConfig,SessionInfo,VoiceReadiness,CallSnapshot,AudioRoute} from './types';
export class CustomerVoiceError extends Error {
  constructor(readonly code:string,readonly status=0){super(code);this.name='CustomerVoiceError'}
}
export function createCustomerVoice(bridge:NativeBridge){
  const subscriptions=new Set<()=>void>();
  async function invoke<T>(method:string,args:Record<string,unknown>={}):Promise<T>{
    try{return await bridge.execute(method,args) as T}catch(error){
      const e=error as {code?:unknown;userInfo?:{code?:unknown;status?:unknown};status?:unknown};
      const raw=e?.userInfo?.code??e?.code;
      const code=typeof raw==='string'&&/^[A-Z][A-Z0-9_]{0,127}$/.test(raw)?raw:'VOICE_OPERATION_FAILED';
      const status=e?.userInfo?.status??e?.status;
      throw new CustomerVoiceError(code,typeof status==='number'?status:0);
    }
  }
  function observe<T>(event:'customerVoiceState'|'customerVoiceEvent',listener:(value:T)=>void,initial:boolean){
    let active=true;let revision=-1;
    const deliver=(value:any)=>{if(!active)return;if(initial){if(typeof value?.revision!=='number'||value.revision<=revision)return;revision=value.revision}listener(value)};
    const detach=bridge.subscribe(event,deliver);
    const off=()=>{if(!active)return;active=false;detach();subscriptions.delete(off)};
    subscriptions.add(off);
    if(initial)void invoke<VoiceState>('getState').then(deliver).catch(()=>{});
    return off;
  }
  return {
    initialize:(config:VoiceConfig)=>invoke<void>('initialize',{...config}),
    login:(userId:string,tenantApiToken:string)=>invoke<SessionInfo>('login',{userId,tenantApiToken}),
    logout:()=>invoke<void>('logout'),checkReadiness:()=>invoke<VoiceReadiness>('checkReadiness'),
    call:(businessNumber:string)=>/^\+?[0-9]{1,32}$/.test(businessNumber)?invoke<CallSnapshot>('call',{businessNumber}):Promise.reject(new CustomerVoiceError('INVALID_BUSINESS_NUMBER')),
    answer:(callId:string)=>invoke<void>('answer',{callId}),reject:(callId:string)=>invoke<void>('reject',{callId}),hangup:(callId:string)=>invoke<void>('hangup',{callId}),
    setMuted:(callId:string,muted:boolean)=>invoke<void>('setMuted',{callId,muted}),
    getAvailableAudioRoutes:(callId:string)=>invoke<AudioRoute[]>('getAvailableAudioRoutes',{callId}),
    selectAudioRoute:(callId:string,routeId:string)=>invoke<void>('selectAudioRoute',{callId,routeId}),
    sendDtmf:(callId:string,digit:string)=>invoke<void>('sendDtmf',{callId,digit}),
    updatePushToken:(token:string)=>invoke<void>('updatePushToken',{token}),unregisterPushToken:()=>invoke<void>('unregisterPushToken'),
    synchronize:()=>invoke<VoiceState>('synchronize'),resume:()=>invoke<void>('resume'),getState:()=>invoke<VoiceState>('getState'),showCall:(callId:string)=>invoke<void>('showCall',{callId}),
    requestMicrophonePermission:()=>invoke<boolean>('requestMicrophonePermission'),
    canShowIncomingScreen:()=>invoke<boolean>('canShowIncomingScreen'),requestIncomingScreenPermission:()=>invoke<void>('requestIncomingScreenPermission'),
    subscribeState:(listener:(state:VoiceState)=>void)=>observe('customerVoiceState',listener,true),
    subscribeEvents:(listener:(event:VoiceEvent)=>void)=>observe('customerVoiceEvent',listener,false),
    dispose:()=>{for(const off of [...subscriptions])off()},
  };
}
export type CustomerVoiceClient=ReturnType<typeof createCustomerVoice>;
