# Customer Voice SDK — React Native

SDK khách hàng React Native **0.1.3**, tái sử dụng CustomerVoice iOS 0.1.2 và Android core/UI 0.4.2. Có login/logout/restore, readiness, gọi CSKH, nhận cuộc gọi, micro, audio route, DTMF, khôi phục mạng 30 giây và UI nghe/gọi native.

Đã ghim consumer React Native 0.88.1 / React 19.3, New Architecture qua native-module interop; không phải JavaScript media engine. Yêu cầu Node 22.13+ (build kiểm chứng Node 24), Android API 26+, iOS 15.1+, Xcode 26.4/Swift 6.3 và JDK 17. RN demo dùng compileSdk 37, build-tools 37 và NDK 28.1; host dùng toolchain phù hợp phiên bản RN của mình. Chưa tuyên bố hỗ trợ các phiên bản RN khác, Expo Go, RN Web hoặc desktop.

## Dùng SDK

Cài `.tgz` trong [bộ demo/hướng dẫn](https://github.com/caresoftgit/guide_demo_user_sdk_react_native/tree/main/packages), cấu hình native bootstrap và push trước khi JS chạy. Xem [API](docs/api.md) và [hướng dẫn tích hợp](https://github.com/caresoftgit/guide_demo_user_sdk_react_native/blob/main/docs/integration.md). Host giữ đầu số được cấp, truyền `call(businessNumber)`; không có API lấy danh sách đầu số.

```ts
import {CustomerVoice} from '@caresoft/customer-voice-react-native';
const off = CustomerVoice.subscribeState(state => {
  // state.readiness.canCall / canReceive; native owns the actual session/call.
});
await CustomerVoice.login(authenticatedUserId, accountToken);
if ((await CustomerVoice.checkReadiness()).canCall) {
  await CustomerVoice.call(assignedBusinessNumber);
}
// off() only removes this observer; it does not hang up or log out.
```

Tài khoản/API token do host xác thực và cấp; không lưu token account trong source, resources, AsyncStorage, log hoặc build config. Không truyền private key APNs/FCM xuống app. Session nằm ở Keystore/Keychain của native SDK. Native UI tự đóng khi call kết thúc; reload JS không dừng native call.

## Phát triển và đóng gói

```sh
npm ci --legacy-peer-deps
# Chuẩn bị shared native artifacts từ native SDK đã được build, không copy source lõi:
python3 scripts/prepare-native.py --ios /path/to/ios-distribution --android /path/to/maven
npm test
npm run typecheck
npm pack
python3 scripts/verify-package.py caresoft-customer-voice-react-native-0.1.3.tgz
```

Không commit output `ios/Vendor`, `android/maven`, node_modules hoặc cấu hình riêng. `npm pack` chứa artifact native và source adapter; kiểm tra `native-manifest.json`/checksum của bộ bàn giao. iOS bundle gồm device và simulator Intel/AppleSilicon; không đóng kèm macOS/tvOS/visionOS. Giữ license/privacy/resource bundle khi phân phối.

- `src/`: public TypeScript API/state observation.
- `android/`: thin Kotlin module, native bootstrap và push forwarding; không có Firebase service trong SDK.
- `ios/`: thin Swift/ObjC module, bootstrap và native presenter.
- `test/`: public facade regression tests.

SDK không tự public lên npm. Demo không chứa server, user, hotline hoặc token test. Kiểm thử unit/build không thay nghiệm thu gọi thật, push, background/lockscreen và chuyển mạng trên thiết bị.

Khi host đang ở Home, dùng `calls[].presentable` và `showCall(callId)` để trở lại cuộc gọi; không gọi `call()` lần nữa.

## Phân phối 0.1.3

Bản này giữ native Android core/UI 0.4.2 và iOS 0.1.2, cập nhật đóng gói để loại đường dẫn máy build và metadata nguồn cục bộ. Source repo chứa bridge, API và script đóng gói; gói dùng ngay có đủ artifact native ở repo demo. Không cài trực tiếp repo source bằng `npm install git+...` vì repo không chứa output native.

Dùng thư mục source/build trung lập để diagnostic runtime không chứa đường dẫn cá nhân. Khi build framework native, ánh xạ đường dẫn nguồn bằng Swift `-file-prefix-map` / `-debug-prefix-map` và Clang `-ffile-prefix-map` trước khi chạy script chuẩn bị. Script loại debug metadata; verifier sẽ từ chối gói còn đường dẫn máy build. Không bỏ license, privacy manifest hoặc resource bundle.
